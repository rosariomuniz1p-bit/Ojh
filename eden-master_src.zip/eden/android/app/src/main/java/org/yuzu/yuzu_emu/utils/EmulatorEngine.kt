// SPDX-FileCopyrightText: Copyright 2026 Eden Emulator Project
// SPDX-License-Identifier: GPL-3.0-or-later

package org.yuzu.yuzu_emu.utils

import android.content.Context

class EmulatorEngine(private val context: Context) {

    companion object {
        init {
            // Carga la librería nativa principal del emulador
            System.loadLibrary("yuzu-android")
        }
    }

    // Declaración del método nativo JNI
    external fun setNativeEnvVariables(cachePath: String)

    fun inicializarEntornoGrafico() {
        // Genera la ruta interna en la memoria caché para los Shaders de Mesa/Zink
        val carpetaCache = "${context.cacheDir.absolutePath}/shaders"
        setNativeEnvVariables(carpetaCache)
    }
}