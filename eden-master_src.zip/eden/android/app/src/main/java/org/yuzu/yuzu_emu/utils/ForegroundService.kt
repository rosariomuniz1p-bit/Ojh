// SPDX-FileCopyrightText: Copyright 2025 Eden Emulator Project
// SPDX-License-Identifier: GPL-3.0-or-later

package org.yuzu.yuzu_emu.utils

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.yuzu.yuzu_emu.R
import org.yuzu.yuzu_emu.activities.EmulationActivity

class ForegroundService : Service() {
    companion object {
        const val EMULATION_RUNNING_NOTIFICATION = 0x1000
        const val ACTION_STOP = "stop"
    }

    private fun showRunningNotification() {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, EmulationActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, getString(R.string.app_notification_channel_id))
            .setSmallIcon(R.drawable.ic_stat_notification_logo)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.app_notification_running))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setVibrate(null)
            .setSound(null)
            .setContentIntent(contentIntent)

        startForeground(EMULATION_RUNNING_NOTIFICATION, builder.build())
    }

    override fun onBind(intent: Intent): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        showRunningNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            try {
                NotificationManagerCompat.from(this).cancel(EMULATION_RUNNING_NOTIFICATION)
                stopForeground(STOP_FOREGROUND_REMOVE)
            } catch (e: Exception) {
                // Control de excepciones silencioso para evitar crashes en hilos nativos
            }
            stopSelfResult(startId)
            return START_NOT_STICKY
        }

        showRunningNotification()
        return START_STICKY
    }

    override fun onDestroy() {
        NotificationManagerCompat.from(this).cancel(EMULATION_RUNNING_NOTIFICATION)
        super.onDestroy()
    }
}